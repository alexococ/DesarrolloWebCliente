window.onload = function(e) {
    console.log('documento cargado')

    // document.getElementsByTagName('h1')[0].innerText = 'Changed from JS!!'
}

const secondH2 = document.querySelectorAll('h2')[1];
if (secondH2) {
    secondH2.textContent = 'titulo cambiado';
}

const usernameElement = document.getElementById('username');

const firstElements = document.querySelectorAll('article .first');
firstElements.forEach(el => {
    el.style.color = 'FF5733'; 
});


const itemElements = document.querySelectorAll('li.item');


const buttonElements = document.querySelectorAll('.buttons button');


const firstParagraph = document.querySelector('p');
if (firstParagraph) {
    firstParagraph.style.backgroundColor = 'CE33FF';
}


buttonElements.forEach(button => {
    button.style.color = '33FFF9';
})