document.addEventListener('DOMContentLoaded', () => {
    // Obtener todos los <div>
    const divElements = document.getElementsByTagName('div');
    Array.from(divElements).forEach((div, index) => {
        console.log(`Div ${index + 1}:`, div);
    });

    // Obtener todos los elementos con class "buttons"
    const buttonElements = document.getElementsByClassName('buttons');
    Array.from(buttonElements).forEach((button, index) => {
        console.log(`Botón ${index + 1}:`, button);
    });

    // Obtener el primer <div> con class "buttons"
    const firstButtonDiv = document.getElementsByClassName('buttons')[0];
    console.log('Primer div con class="buttons":', firstButtonDiv);

    // Obtener todos los <div> con class "buttons"
    const allButtonDivs = document.getElementsByClassName('buttons');
    Array.from(allButtonDivs).forEach((buttonDiv, index) => {
        console.log(`Div con class="buttons" ${index + 1}:`, buttonDiv);
    });
});
