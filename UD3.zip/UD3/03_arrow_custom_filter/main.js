const assert = require('assert').strict;





/**************EJERCICIO 3**************/

function pairs(values){
    return values.filter((numero) => numero%2 === 0)
}

function gt15(values){
    return values.filter((numero) => numero > 15)
}

function lt10(values){
    return values.filter((numero) => numero < 10)
}

let values = [1, 2, 3, 5, 7, 13, 17, 23, 29]

// sólo pares
assert.deepStrictEqual(pairs(values), [2])
console.log('correct');

// mayores que 15
assert.deepStrictEqual(gt15(values), [17, 23, 29])

// menores de 10
assert.deepStrictEqual(lt10(values), [1, 2, 3, 5, 7])